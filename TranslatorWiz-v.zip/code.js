"use strict";
// TranslatorWiz - Figma plugin for Contentful-based translations
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.showUI(__html__, { width: 900, height: 500, themeColors: true });
// Network timeout for API calls (10 seconds)
const API_TIMEOUT = 10000;
// Default config
const defaultConfig = {
    SPACE_ID: "",
    ENVIRONMENT: "master",
    CMA_TOKEN: "",
    CONTENT_TYPE: "translation",
    KEY_FIELD: "key",
    VALUE_FIELD: "value",
    NODE_NAME_PATTERN: "^jams_"
};
// Load config from storage or use default
let configData = defaultConfig;
function loadConfigFromStorage() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const stored = yield figma.clientStorage.getAsync('translatorwiz_config');
            if (stored && typeof stored === 'object') {
                return Object.assign(Object.assign({}, defaultConfig), stored);
            }
        }
        catch (e) {
            console.error('Failed to load config from storage:', e);
        }
        return defaultConfig;
    });
}
function saveConfigToStorage(config) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield figma.clientStorage.setAsync('translatorwiz_config', config);
        }
        catch (e) {
            throw new Error('Failed to save config to storage');
        }
    });
}
// Validate config on startup
function validateConfig(config) {
    if (!config.SPACE_ID || !config.SPACE_ID.trim()) {
        return 'SPACE_ID is required';
    }
    if (!config.ENVIRONMENT || !config.ENVIRONMENT.trim()) {
        return 'ENVIRONMENT is required';
    }
    if (!config.CMA_TOKEN || !config.CMA_TOKEN.trim()) {
        return 'CMA_TOKEN is required';
    }
    if (!config.CONTENT_TYPE || !config.CONTENT_TYPE.trim()) {
        return 'CONTENT_TYPE is required';
    }
    if (!config.KEY_FIELD || !config.KEY_FIELD.trim()) {
        return 'KEY_FIELD is required';
    }
    if (!config.VALUE_FIELD || !config.VALUE_FIELD.trim()) {
        return 'VALUE_FIELD is required';
    }
    if (!config.NODE_NAME_PATTERN || !config.NODE_NAME_PATTERN.trim()) {
        return 'NODE_NAME_PATTERN is required';
    }
    // Validate regex pattern
    try {
        new RegExp(config.NODE_NAME_PATTERN);
    }
    catch (e) {
        return `Invalid regex pattern: ${config.NODE_NAME_PATTERN}`;
    }
    return null;
}
// Listen for selection changes in Figma
figma.on('selectionchange', () => {
    const selection = figma.currentPage.selection;
    if (selection.length === 1 && selection[0].type === 'TEXT') {
        const textNode = selection[0];
        figma.ui.postMessage({
            type: 'text-node-selected',
            nodeName: textNode.name,
            nodeText: textNode.characters
        });
    }
});
figma.ui.onmessage = (msg) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        if (msg.type === 'init') {
            // Load config from storage
            configData = yield loadConfigFromStorage();
            // Always send config to UI (even if incomplete) so UI can show onboarding
            figma.ui.postMessage({ type: 'config-loaded', config: configData });
            // Count translatable nodes and send to UI (only if config is valid)
            const configError = validateConfig(configData);
            if (!configError) {
                const nodeCount = getTranslatableNodeCount(configData);
                figma.ui.postMessage({ type: 'node-count', count: nodeCount });
            }
            return;
        }
        if (msg.type === 'save-config') {
            if (!msg.config) {
                figma.ui.postMessage({ type: 'config-save-failed', message: 'No config provided' });
                return;
            }
            // Validate new config
            const configError = validateConfig(msg.config);
            if (configError) {
                figma.ui.postMessage({ type: 'config-save-failed', message: configError });
                return;
            }
            // Save to storage
            yield saveConfigToStorage(msg.config);
            configData = msg.config;
            figma.ui.postMessage({ type: 'config-saved', config: configData });
            // Reload locales with new config
            const nodeCount = getTranslatableNodeCount(configData);
            figma.ui.postMessage({ type: 'node-count', count: nodeCount });
            return;
        }
        // Preflight check: Test by fetching locales (validates credentials, space, and environment)
        if (msg.type === 'preflight-test-locales') {
            if (!msg.config) {
                figma.ui.postMessage({
                    type: 'preflight-locales-result',
                    result: { success: false, error: 'No config provided' }
                });
                return;
            }
            try {
                const locales = yield fetchLocales(msg.config);
                if (locales.length === 0) {
                    throw new Error('No locales found');
                }
                figma.ui.postMessage({
                    type: 'preflight-locales-result',
                    result: { success: true, message: `Found ${locales.length} locale(s) ✓` }
                });
            }
            catch (error) {
                const errorMsg = error instanceof Error ? error.message : 'Failed to fetch locales';
                figma.ui.postMessage({
                    type: 'preflight-locales-result',
                    result: { success: false, error: errorMsg }
                });
            }
            return;
        }
        // Preflight check: Check content type
        if (msg.type === 'preflight-check-content') {
            if (!msg.config) {
                figma.ui.postMessage({
                    type: 'preflight-content-result',
                    result: { success: false, error: 'No config provided' }
                });
                return;
            }
            try {
                const spaceId = encodeURIComponent(msg.config.SPACE_ID);
                const environment = encodeURIComponent(msg.config.ENVIRONMENT);
                const contentType = encodeURIComponent(msg.config.CONTENT_TYPE);
                const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/content_types/${contentType}`;
                const options = {
                    headers: {
                        'Authorization': `Bearer ${msg.config.CMA_TOKEN}`
                    }
                };
                const response = yield fetchWithTimeout(url, options, API_TIMEOUT);
                if (!response.ok) {
                    if (response.status === 404) {
                        throw new Error(`Content type not found`);
                    }
                    throw new Error('Content type check failed');
                }
                const data = yield response.json();
                // Verify required fields exist
                const fields = Array.isArray(data.fields) ? data.fields : [];
                const fieldNames = fields.map((f) => (f && typeof f.id === 'string') ? f.id : '');
                if (!fieldNames.includes(msg.config.KEY_FIELD)) {
                    throw new Error(`Key field not found in content type`);
                }
                if (!fieldNames.includes(msg.config.VALUE_FIELD)) {
                    throw new Error(`Value field not found in content type`);
                }
                figma.ui.postMessage({
                    type: 'preflight-content-result',
                    result: { success: true, message: `Content type validated ✓` }
                });
            }
            catch (error) {
                const errorMsg = error instanceof Error ? error.message : 'Content type check failed';
                figma.ui.postMessage({
                    type: 'preflight-content-result',
                    result: { success: false, error: errorMsg }
                });
            }
            return;
        }
        if (msg.type === 'load-locales') {
            if (!msg.config) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration missing' });
                return;
            }
            // Validate config
            const configError = validateConfig(msg.config);
            if (configError) {
                figma.ui.postMessage({ type: 'error', message: `Config error: ${configError}` });
                return;
            }
            const locales = yield fetchLocales(msg.config);
            if (locales.length === 0) {
                figma.ui.postMessage({ type: 'error', message: 'No locales found in Contentful' });
                return;
            }
            figma.ui.postMessage({ type: 'locales-loaded', locales });
            return;
        }
        if (msg.type === 'apply-translation') {
            if (!msg.config || !msg.locale) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration or locale missing' });
                return;
            }
            // Validate config
            const configError = validateConfig(msg.config);
            if (configError) {
                figma.ui.postMessage({ type: 'error', message: `Config error: ${configError}` });
                return;
            }
            // Validate locale
            if (!msg.locale.trim()) {
                figma.ui.postMessage({ type: 'error', message: 'Please select a valid locale' });
                return;
            }
            // Pre-flight check: verify translatable nodes exist
            const nodeCount = getTranslatableNodeCount(msg.config);
            if (nodeCount === 0) {
                figma.ui.postMessage({ type: 'error', message: 'No translatable text nodes found on current page' });
                return;
            }
            const translations = yield fetchTranslations(msg.config, msg.locale);
            if (translations.length === 0) {
                figma.ui.postMessage({ type: 'error', message: `No translations found for locale: ${msg.locale}` });
                return;
            }
            const count = yield applyTranslations(translations, msg.config);
            figma.ui.postMessage({ type: 'translation-applied', count });
            // Update node count after translation
            const updatedNodeCount = getTranslatableNodeCount(msg.config);
            figma.ui.postMessage({ type: 'node-count', count: updatedNodeCount });
            return;
        }
        // Content Preview Mode handlers
        if (msg.type === 'load-content-types') {
            if (!msg.config) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration missing' });
                return;
            }
            try {
                const contentTypes = yield fetchContentTypes(msg.config);
                figma.ui.postMessage({ type: 'content-types-loaded', contentTypes });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        if (msg.type === 'get-text-nodes') {
            try {
                const textNodes = getAllTextNodes();
                figma.ui.postMessage({ type: 'text-nodes-loaded', nodes: textNodes });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        if (msg.type === 'load-records') {
            if (!msg.config || !msg.contentType) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration or content type missing' });
                return;
            }
            try {
                const records = yield fetchRecords(msg.config, msg.contentType);
                figma.ui.postMessage({ type: 'records-loaded', records });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        if (msg.type === 'load-multiple-records') {
            if (!msg.config || !msg.contentTypes) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration or content types missing' });
                return;
            }
            try {
                const recordsByContentType = {};
                // Load records from each content type
                for (const contentType of msg.contentTypes) {
                    const records = yield fetchRecords(msg.config, contentType);
                    recordsByContentType[contentType] = records;
                }
                figma.ui.postMessage({ type: 'multiple-records-loaded', recordsByContentType });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        if (msg.type === 'apply-record-to-nodes') {
            if (!msg.mappings || !msg.recordFields) {
                figma.ui.postMessage({ type: 'error', message: 'Mappings or record data missing' });
                return;
            }
            try {
                yield applyRecordToNodes(msg.mappings, msg.recordFields);
                figma.ui.postMessage({ type: 'record-applied' });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        // Write mode handlers
        if (msg.type === 'get-translatable-nodes') {
            if (!msg.config) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration missing' });
                return;
            }
            try {
                const pattern = new RegExp(msg.config.NODE_NAME_PATTERN);
                const textNodes = figma.currentPage.findAll((n) => n.type === 'TEXT' && pattern.test(n.name));
                const nodes = textNodes.map(node => ({
                    id: node.id,
                    name: node.name,
                    characters: node.characters
                }));
                figma.ui.postMessage({ type: 'translatable-nodes-loaded', nodes });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        if (msg.type === 'get-all-contentful-items') {
            if (!msg.config) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration missing' });
                return;
            }
            try {
                const items = yield fetchAllContentfulItems(msg.config);
                figma.ui.postMessage({ type: 'contentful-items-loaded', items });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                figma.ui.postMessage({ type: 'error', message: errorMessage });
            }
            return;
        }
        if (msg.type === 'save-contentful-item') {
            if (!msg.config || !msg.item) {
                figma.ui.postMessage({ type: 'error', message: 'Configuration or item missing' });
                return;
            }
            try {
                const result = yield saveItemToContentful(msg.config, msg.item);
                figma.ui.postMessage({
                    type: 'item-saved',
                    key: msg.item.key,
                    success: result.success,
                    error: result.error,
                    errorDetails: result.errorDetails
                });
            }
            catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                const errorDetails = error instanceof Error ? { exception: error.name, stack: error.stack } : { exception: String(error) };
                figma.ui.postMessage({
                    type: 'item-saved',
                    key: msg.item.key,
                    success: false,
                    error: errorMessage,
                    errorDetails
                });
            }
            return;
        }
        if (msg.type === 'cancel') {
            figma.closePlugin();
            return;
        }
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        figma.ui.postMessage({ type: 'error', message: errorMessage });
    }
});
function getTranslatableNodeCount(config) {
    const pattern = new RegExp(config.NODE_NAME_PATTERN);
    const textNodes = figma.currentPage.findAll((n) => n.type === 'TEXT' && pattern.test(n.name));
    return textNodes.length;
}
function fetchWithTimeout(url_1, options_1) {
    return __awaiter(this, arguments, void 0, function* (url, options, timeout = API_TIMEOUT) {
        return new Promise((resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error('Request timeout - please check your network connection'));
            }, timeout);
            fetch(url, options)
                .then(response => {
                clearTimeout(timeoutId);
                resolve(response);
            })
                .catch(error => {
                clearTimeout(timeoutId);
                reject(error);
            });
        });
    });
}
function fetchLocales(config) {
    return __awaiter(this, void 0, void 0, function* () {
        const spaceId = encodeURIComponent(config.SPACE_ID);
        const environment = encodeURIComponent(config.ENVIRONMENT);
        const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/locales`;
        const options = {
            headers: {
                'Authorization': `Bearer ${config.CMA_TOKEN}`
            }
        };
        try {
            const response = yield fetchWithTimeout(url, options, API_TIMEOUT);
            if (!response.ok) {
                if (response.status === 401 || response.status === 403) {
                    throw new Error('Invalid API credentials');
                }
                if (response.status === 404) {
                    throw new Error('Space or environment not found');
                }
                throw new Error('Failed to fetch locales');
            }
            const data = yield response.json();
            if (!data.items || !Array.isArray(data.items)) {
                throw new Error('Invalid response format');
            }
            return data.items
                .map((item) => ({
                code: (item && typeof item.code === 'string') ? item.code : '',
                name: (item && typeof item.name === 'string') ? item.name : ''
            }))
                .filter((item) => item.code.trim() !== '' && item.name.trim() !== '');
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to load locales: ${error.message}`);
            }
            throw error;
        }
    });
}
function fetchTranslations(config, locale) {
    return __awaiter(this, void 0, void 0, function* () {
        // Validate and sanitize locale input
        if (!locale || typeof locale !== 'string' || locale.trim() === '') {
            throw new Error('Invalid locale');
        }
        const spaceId = encodeURIComponent(config.SPACE_ID);
        const environment = encodeURIComponent(config.ENVIRONMENT);
        const contentType = encodeURIComponent(config.CONTENT_TYPE);
        const localeParam = encodeURIComponent(locale.trim());
        const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/entries?content_type=${contentType}&locale=${localeParam}`;
        const options = {
            headers: {
                'Authorization': `Bearer ${config.CMA_TOKEN}`
            }
        };
        try {
            const response = yield fetchWithTimeout(url, options, API_TIMEOUT);
            if (!response.ok) {
                if (response.status === 401 || response.status === 403) {
                    throw new Error('Invalid API credentials');
                }
                if (response.status === 404) {
                    throw new Error('Content type not found');
                }
                throw new Error('Failed to fetch translations');
            }
            const data = yield response.json();
            if (!data.items || !Array.isArray(data.items)) {
                throw new Error('Invalid response format');
            }
            return data.items
                .map((item) => {
                const fields = (item && typeof item.fields === 'object') ? item.fields : {};
                return {
                    key: (typeof fields[config.KEY_FIELD] === 'string') ? fields[config.KEY_FIELD] : '',
                    value: (typeof fields[config.VALUE_FIELD] === 'string') ? fields[config.VALUE_FIELD] : ''
                };
            })
                .filter((t) => t.key.trim() !== '' && t.value.trim() !== '');
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to load translations: ${error.message}`);
            }
            throw error;
        }
    });
}
function applyTranslations(translations, config) {
    return __awaiter(this, void 0, void 0, function* () {
        const translationMap = new Map();
        for (const t of translations) {
            if (t.key && t.value) {
                translationMap.set(t.key, t.value);
            }
        }
        const pattern = new RegExp(config.NODE_NAME_PATTERN);
        const textNodes = figma.currentPage.findAll((n) => n.type === 'TEXT' && pattern.test(n.name));
        if (textNodes.length === 0) {
            throw new Error('No translatable text nodes found on current page');
        }
        let count = 0;
        const errors = [];
        const skipped = [];
        for (const node of textNodes) {
            // Check if node is locked
            if (node.locked) {
                skipped.push(`${node.name}: Locked`);
                continue;
            }
            const translation = translationMap.get(node.name);
            if (translation) {
                try {
                    // Handle mixed fonts in text nodes
                    if (node.hasMissingFont) {
                        errors.push(`${node.name}: Missing font`);
                        continue;
                    }
                    // Load all unique fonts in the text node
                    const fontName = node.fontName;
                    if (fontName === figma.mixed) {
                        // Text has mixed fonts, load all ranges
                        const uniqueFonts = new Set();
                        for (let i = 0; i < node.characters.length; i++) {
                            const font = node.getRangeFontName(i, i + 1);
                            uniqueFonts.add(`${font.family}:${font.style}`);
                            yield figma.loadFontAsync(font);
                        }
                    }
                    else {
                        yield figma.loadFontAsync(fontName);
                    }
                    node.characters = translation;
                    count++;
                }
                catch (fontError) {
                    errors.push(`${node.name}: ${fontError instanceof Error ? fontError.message : 'Font error'}`);
                }
            }
        }
        if (count === 0) {
            if (errors.length > 0) {
                throw new Error(`Translation failed: ${errors[0]}`);
            }
            if (skipped.length > 0) {
                throw new Error(`All nodes skipped: ${skipped[0]}`);
            }
            throw new Error('No matching translations found for text nodes');
        }
        return count;
    });
}
// ========== Content Preview Mode Functions ==========
function fetchContentTypes(config) {
    return __awaiter(this, void 0, void 0, function* () {
        const spaceId = encodeURIComponent(config.SPACE_ID);
        const environment = encodeURIComponent(config.ENVIRONMENT);
        const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/content_types`;
        const options = {
            headers: {
                'Authorization': `Bearer ${config.CMA_TOKEN}`
            }
        };
        try {
            const response = yield fetchWithTimeout(url, options, API_TIMEOUT);
            if (!response.ok) {
                if (response.status === 401 || response.status === 403) {
                    throw new Error('Invalid API credentials');
                }
                if (response.status === 404) {
                    throw new Error('Space or environment not found');
                }
                throw new Error('Failed to fetch content types');
            }
            const data = yield response.json();
            if (!data.items || !Array.isArray(data.items)) {
                throw new Error('Invalid response format');
            }
            return data.items;
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to load content types: ${error.message}`);
            }
            throw error;
        }
    });
}
function getAllTextNodes() {
    const textNodes = figma.currentPage.findAll((n) => n.type === 'TEXT');
    return textNodes.map(node => ({
        id: node.id,
        name: node.name,
        characters: node.characters
    }));
}
function fetchRecords(config, contentType) {
    return __awaiter(this, void 0, void 0, function* () {
        const spaceId = encodeURIComponent(config.SPACE_ID);
        const environment = encodeURIComponent(config.ENVIRONMENT);
        const contentTypeParam = encodeURIComponent(contentType);
        const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/entries?content_type=${contentTypeParam}&limit=100`;
        const options = {
            headers: {
                'Authorization': `Bearer ${config.CMA_TOKEN}`
            }
        };
        try {
            const response = yield fetchWithTimeout(url, options, API_TIMEOUT);
            if (!response.ok) {
                if (response.status === 401 || response.status === 403) {
                    throw new Error('Invalid API credentials');
                }
                if (response.status === 404) {
                    throw new Error('Content type not found');
                }
                throw new Error('Failed to fetch records');
            }
            const data = yield response.json();
            if (!data.items || !Array.isArray(data.items)) {
                throw new Error('Invalid response format');
            }
            return data.items;
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to load records: ${error.message}`);
            }
            throw error;
        }
    });
}
function applyRecordToNodes(mappings, recordFields) {
    return __awaiter(this, void 0, void 0, function* () {
        const errors = [];
        for (const mapping of mappings) {
            try {
                const node = figma.getNodeById(mapping.node);
                if (!node || node.type !== 'TEXT') {
                    errors.push(`Node not found: ${mapping.node}`);
                    continue;
                }
                if (node.locked) {
                    errors.push(`Node is locked: ${node.name}`);
                    continue;
                }
                const fieldValue = recordFields[mapping.field];
                if (fieldValue === undefined || fieldValue === null) {
                    continue; // Skip if field value doesn't exist
                }
                const textValue = String(fieldValue);
                // Handle fonts
                if (node.hasMissingFont) {
                    errors.push(`Missing font in node: ${node.name}`);
                    continue;
                }
                const fontName = node.fontName;
                if (fontName === figma.mixed) {
                    // Text has mixed fonts, load all ranges
                    const uniqueFonts = new Set();
                    for (let i = 0; i < node.characters.length; i++) {
                        const font = node.getRangeFontName(i, i + 1);
                        uniqueFonts.add(`${font.family}:${font.style}`);
                        yield figma.loadFontAsync(font);
                    }
                }
                else {
                    yield figma.loadFontAsync(fontName);
                }
                node.characters = textValue;
            }
            catch (error) {
                const errorMsg = error instanceof Error ? error.message : 'Unknown error';
                errors.push(`Error applying to node: ${errorMsg}`);
            }
        }
        if (errors.length > 0) {
            console.warn('Some mappings failed:', errors);
        }
    });
}
// ========== Write Mode Functions ==========
function fetchAllContentfulItems(config) {
    return __awaiter(this, void 0, void 0, function* () {
        const spaceId = encodeURIComponent(config.SPACE_ID);
        const environment = encodeURIComponent(config.ENVIRONMENT);
        const contentType = encodeURIComponent(config.CONTENT_TYPE);
        const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/entries?content_type=${contentType}&limit=1000`;
        const options = {
            headers: {
                'Authorization': `Bearer ${config.CMA_TOKEN}`
            }
        };
        try {
            const response = yield fetchWithTimeout(url, options, API_TIMEOUT);
            if (!response.ok) {
                throw new Error('Failed to fetch Contentful items');
            }
            const data = yield response.json();
            const items = {};
            if (data.items && Array.isArray(data.items)) {
                for (const item of data.items) {
                    // Skip archived entries only (unpublished entries are OK)
                    const isArchived = item.sys.archivedVersion !== undefined;
                    if (isArchived) {
                        console.log(`Skipping archived entry ${item.sys.id}`);
                        continue;
                    }
                    const fields = item.fields || {};
                    // CMA API returns fields in localized format: { 'en-US': 'value' }
                    const keyField = fields[config.KEY_FIELD];
                    const valueField = fields[config.VALUE_FIELD];
                    // Get the actual value from the locale (default to 'en-US' or first available locale)
                    let key = null;
                    let value = null;
                    if (keyField && typeof keyField === 'object') {
                        key = keyField['en-US'] || keyField[Object.keys(keyField)[0]];
                    }
                    if (valueField && typeof valueField === 'object') {
                        value = valueField['en-US'] || valueField[Object.keys(valueField)[0]];
                    }
                    if (key && value) {
                        items[key] = {
                            value: value,
                            id: item.sys.id
                        };
                    }
                }
            }
            return items;
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to fetch Contentful items: ${error.message}`);
            }
            throw error;
        }
    });
}
function saveItemToContentful(config, item) {
    return __awaiter(this, void 0, void 0, function* () {
        const spaceId = encodeURIComponent(config.SPACE_ID);
        const environment = encodeURIComponent(config.ENVIRONMENT);
        const contentType = config.CONTENT_TYPE;
        try {
            if (item.isUpdate && item.entryId) {
                // Update existing entry
                const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/entries/${item.entryId}`;
                // First, get the current entry to get the version
                const getResponse = yield fetchWithTimeout(url, {
                    headers: {
                        'Authorization': `Bearer ${config.CMA_TOKEN}`
                    }
                }, API_TIMEOUT);
                if (!getResponse.ok) {
                    const errorText = yield getResponse.text();
                    console.error('[Contentful] Failed to fetch entry for update:', errorText);
                    return {
                        success: false,
                        error: `Could not fetch entry (${getResponse.status})`,
                        errorDetails: { status: getResponse.status, response: errorText, operation: 'fetch', entryId: item.entryId }
                    };
                }
                const currentEntry = yield getResponse.json();
                const version = currentEntry.sys.version;
                // Update the entry
                const updateResponse = yield fetchWithTimeout(url, {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${config.CMA_TOKEN}`,
                        'Content-Type': 'application/vnd.contentful.management.v1+json',
                        'X-Contentful-Version': version.toString()
                    },
                    body: JSON.stringify({
                        fields: {
                            [config.KEY_FIELD]: { 'en-US': item.key },
                            [config.VALUE_FIELD]: { 'en-US': item.value }
                        }
                    })
                }, API_TIMEOUT);
                if (!updateResponse.ok) {
                    const errorText = yield updateResponse.text();
                    console.error('[Contentful] Update failed:', errorText);
                    return {
                        success: false,
                        error: `Update failed (${updateResponse.status})`,
                        errorDetails: { status: updateResponse.status, response: errorText, operation: 'update', entryId: item.entryId, version }
                    };
                }
                // Publish the updated entry
                const updatedEntry = yield updateResponse.json();
                const publishUrl = `${url}/published`;
                const publishResponse = yield fetchWithTimeout(publishUrl, {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${config.CMA_TOKEN}`,
                        'X-Contentful-Version': updatedEntry.sys.version.toString()
                    }
                }, API_TIMEOUT);
                if (!publishResponse.ok) {
                    const errorText = yield publishResponse.text();
                    console.error('[Contentful] Publish failed:', errorText);
                    return {
                        success: false,
                        error: `Publish failed (${publishResponse.status})`,
                        errorDetails: { status: publishResponse.status, response: errorText, operation: 'publish', entryId: item.entryId }
                    };
                }
                return { success: true };
            }
            else {
                // Create new entry
                const url = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/entries`;
                const createResponse = yield fetchWithTimeout(url, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${config.CMA_TOKEN}`,
                        'Content-Type': 'application/vnd.contentful.management.v1+json',
                        'X-Contentful-Content-Type': contentType
                    },
                    body: JSON.stringify({
                        fields: {
                            [config.KEY_FIELD]: { 'en-US': item.key },
                            [config.VALUE_FIELD]: { 'en-US': item.value }
                        }
                    })
                }, API_TIMEOUT);
                if (!createResponse.ok) {
                    const errorText = yield createResponse.text();
                    console.error('[Contentful] Create failed:', errorText);
                    return {
                        success: false,
                        error: `Create failed (${createResponse.status})`,
                        errorDetails: { status: createResponse.status, response: errorText, operation: 'create', key: item.key }
                    };
                }
                // Publish the new entry
                const newEntry = yield createResponse.json();
                const publishUrl = `https://api.contentful.com/spaces/${spaceId}/environments/${environment}/entries/${newEntry.sys.id}/published`;
                const publishResponse = yield fetchWithTimeout(publishUrl, {
                    method: 'PUT',
                    headers: {
                        'Authorization': `Bearer ${config.CMA_TOKEN}`,
                        'X-Contentful-Version': newEntry.sys.version.toString()
                    }
                }, API_TIMEOUT);
                if (!publishResponse.ok) {
                    const errorText = yield publishResponse.text();
                    console.error('[Contentful] Publish after create failed:', errorText);
                    return {
                        success: false,
                        error: `Created but publish failed (${publishResponse.status})`,
                        errorDetails: { status: publishResponse.status, response: errorText, operation: 'publish-new', entryId: newEntry.sys.id }
                    };
                }
                return { success: true };
            }
        }
        catch (error) {
            console.error('[Contentful] Exception:', error);
            if (error instanceof Error) {
                return {
                    success: false,
                    error: error.message,
                    errorDetails: { exception: error.name, stack: error.stack, operation: item.isUpdate ? 'update' : 'create' }
                };
            }
            return {
                success: false,
                error: 'Unknown error occurred',
                errorDetails: { exception: String(error) }
            };
        }
    });
}
